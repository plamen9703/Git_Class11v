package edu.npmg.v11;

import java.util.Scanner;

public class Session {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Hello there " + scan.nextLine());
//		scan.close();
		
		//whole number
		//byte, short, int, long
		
		//real numbers
		//double, float
		
		//boolean - true, false
		
		//String - text >> ""
		//char - one symbol >> ''
		
		int a=scan.nextInt();
		String text= scan.nextLine();
		
		if( 13 /5 ==0) 
			System.out.println("YES");
		else if (13%5==3)
			System.out.print("NO YES");
		else 
			System.out.print("NO");
		
		System.out.print((13/5!=0) ? text : text+13); 
		
		
	}

}
