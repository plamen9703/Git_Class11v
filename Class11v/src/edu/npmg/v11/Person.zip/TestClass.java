package edu.npmg.v11;

public class TestClass {

	public static void main(String[] args) {
		Person p=new Person("Steafan", 12,140,40);
		Person.getBMI(p);
		Person p1=new Person();
//		p.name="Plamen";
//		p.age=25;
//		p.height=178;
//		p.weidth=112.8;
//		p.setName("Stefan");
		System.out.println(p);
		System.out.println(p1);
//		System.out.println(Person.getBMI(p));
//		p.printLocation();
//		p.jump();
//		p.printLocation();
//		p.fall();
//		p.printLocation();
	}

}
